# Painel SuperAção SP — protótipo Streamlit

Identidade visual conforme **Manual de Identidade Visual do Governo do Estado de
São Paulo**, GESP v1.6, abr 2023.

## Estrutura

```
painel/
├── app.py                    aplicação
├── .streamlit/config.toml    tema com as cores oficiais
├── dados/                    saída da camada agregada (versão publicável)
│   ├── funil.csv
│   ├── tempos.csv
│   ├── recusas.csv
│   └── qualidade.csv
└── marcas/                   arquivos de logotipo
    ├── sp_governo_horizontal_negativo.png
    └── bid.png
```

## Rodar

```bash
pip install streamlit pandas
streamlit run app.py
```

Abre em `http://localhost:8501`. Enquanto os arquivos de `marcas/` não existirem,
aparecem espaços reservados tracejados no lugar dos logotipos.

**Colab não é bom ambiente para isto.** O Streamlit sobe um servidor, e no Colab
seria preciso túnel externo. Para o protótipo, rode na sua máquina.

## Acrescentar um relatório

Duas alterações:

```python
def rel_novo(d: dict) -> None:
    secao("Título da seção")
    linha_cartoes([("Rótulo", "42%", "apoio")])

RELATORIOS = [
    ...,
    {"titulo": "Novo relatório", "fn": rel_novo, "status": "atual"},
]
```

A navegação, o marcador de situação e o título do cabeçalho se ajustam sozinhos.

## Decisões de identidade

| Elemento | Valor | Origem |
|---|---|---|
| Vermelho | `#FF161F` PANTONE 485 C | p. 10 |
| Preto | `#000000` PANTONE BLACK | p. 10 |
| Cinza 50% / 25% | `#808080` / `#BFBFBF` | p. 10 |
| Amarelo | `#FBB900` PANTONE 123 C | p. 10, paleta secundária |
| Azul | `#034EA2` PANTONE 2955 C | p. 10, paleta secundária |
| Verde | `#0B9247` PANTONE 347 C | p. 10, paleta secundária |
| Tipografia | Verdana | p. 24, 28, 29 |
| Grid | 12 colunas, 30px; 4 colunas <576px | p. 26 |
| Régua de logotipos | parceiros à esquerda, Governo à direita | p. 19, 21 |
| Tamanho mínimo digital | H = 5px | p. 12 |

**Papéis das cores no painel.** O vermelho fica reservado à identidade — faixa
superior, filete, marcador do item ativo, traço sob os títulos. Ele não é usado
como cor de alerta: num painel assinado pelo Governo do Estado, vermelho já
significa "Governo", e usá-lo também para desempenho ruim faz o cabeçalho inteiro
parecer alarme. Advertência usa o amarelo `#FBB900` da paleta secundária.

**Divergência no manual.** Na p. 10, o vermelho aparece como `#FF161F` mas com
RGB 237/28/36, que corresponde a `#ED1C24`. O código usa o hexadecimal impresso.
Vale confirmar com a Secretaria Especial de Comunicação qual prevalece.
