"""
Painel SuperAção SP — protótipo em Streamlit.

Identidade visual conforme MANUAL DE IDENTIDADE VISUAL do Governo do Estado de
São Paulo (GESP v1.6, abr 2023). Referências de página no código.

Rodar:      streamlit run app.py
Requisitos: streamlit, pandas

Para acrescentar um relatório: escreva uma função que recebe o dicionário de
tabelas e desenha na tela, e registre uma entrada em RELATORIOS.
"""

from __future__ import annotations

import base64
from datetime import datetime
from pathlib import Path

import pandas as pd
import streamlit as st

# =====================================================================
# CONFIGURAÇÃO
# =====================================================================

DIR_TABELAS = Path("dados")          # pasta com funil.csv, tempos.csv, recusas.csv, qualidade.csv
DIR_MARCAS = Path("marcas")          # pasta com os arquivos de logotipo

COMPETENCIA = "junho de 2026"
VERSAO = "protótipo v0.4"

ORGAO = "Secretaria de Desenvolvimento Social"
PROGRAMA = "SuperAção SP"
FONTE = "Fonte: SIGMA/SEDS-SP. Elaboração própria."
NOTA_SUPRESSAO = (
    "Células com menos de 5 famílias são omitidas. Municípios com menos de "
    "30 elegíveis ficam fora da comparação de taxas."
)

N_MIN_COMPARATIVO = 30

# --- Marcas ----------------------------------------------------------
# Ordem da assinatura conforme manual p. 19 e 21: os logos parceiros ficam à
# ESQUERDA e o logotipo do Governo SEMPRE à direita. A secretaria assina
# imediatamente à esquerda do logotipo do Governo.
# Nenhum logo parceiro pode ultrapassar 1,5X da largura do símbolo SP (p. 19).
LOGO_GOVERNO = DIR_MARCAS / "sp_governo_horizontal_negativo.png"  # uso prioritário, p. 4
LOGO_PARCEIROS = [DIR_MARCAS / "bid.png"]

# =====================================================================
# IDENTIDADE VISUAL — valores do manual, p. 10
# =====================================================================

# Paleta principal
VERMELHO = "#FF161F"   # PANTONE 485 C
PRETO = "#000000"      # PANTONE BLACK
BRANCO = "#FFFFFF"
CINZA_50 = "#808080"
CINZA_25 = "#BFBFBF"

# Paleta secundária
AMARELO = "#FBB900"    # PANTONE 123 C
AZUL = "#034EA2"       # PANTONE 2955 C
VERDE = "#0B9247"      # PANTONE 347 C

# Papéis no painel.
# O vermelho é a cor da marca e fica reservado à identidade (barra, marcadores,
# traço de seção). Ele NÃO é usado como cor de alerta: num painel assinado pelo
# Governo, vermelho já significa "governo", e usá-lo também para "ruim" faz o
# leitor ler alarme onde só há cabeçalho. Atenção usa o amarelo da paleta
# secundária, que é o código de advertência sem competir com a marca.
COR_SERIE = AZUL
COR_POSITIVO = VERDE
COR_ATENCAO = AMARELO
COR_MARCA = VERMELHO

# Tipografia: o manual determina Verdana como fonte de sistema para comunicação
# institucional (assinatura de e-mail p. 24, papel timbrado p. 29, cartão p. 28).
FONTE_TIPO = "Verdana, Geneva, 'DejaVu Sans', sans-serif"

# Grid: 12 colunas com espaçamento de 30px em telas ≥1200px; 4 colunas
# em telas <576px (p. 26).
GUTTER = 30


def css() -> str:
    return f"""
<style>
:root {{
  --vermelho:{VERMELHO}; --preto:{PRETO}; --branco:{BRANCO};
  --cinza50:{CINZA_50}; --cinza25:{CINZA_25};
  --amarelo:{AMARELO}; --azul:{AZUL}; --verde:{VERDE};
  --serie:{COR_SERIE}; --gutter:{GUTTER}px;
}}

html, body, [class*="css"], .stMarkdown, .stApp {{
  font-family:{FONTE_TIPO};
}}
.stApp {{ background:var(--branco); }}

/* Cromo do Streamlit fora do caminho */
#MainMenu, footer {{ visibility:hidden; }}
.stDeployButton {{ display:none; }}
.block-container {{ padding:0 var(--gutter) 3rem; max-width:1400px; }}

/* ---------- Barra superior (assinatura institucional) ---------- */
.faixa {{
  background:var(--preto); margin:0 calc(-1 * var(--gutter)) 0;
  padding:16px var(--gutter); display:flex; align-items:flex-end;
  justify-content:space-between; gap:24px; flex-wrap:wrap;
}}
.faixa-titulo {{
  color:var(--branco); font-size:19px; font-weight:bold;
  letter-spacing:.01em; margin:0; line-height:1.2;
}}
.faixa-sub {{ color:var(--cinza25); font-size:12px; margin:4px 0 0; }}

/* Régua de logotipos: parceiros à esquerda, Governo à direita (p. 19) */
.regua {{ display:flex; align-items:flex-end; gap:20px; }}
.regua-slot {{
  height:34px; min-width:78px; display:flex; align-items:center;
  justify-content:center; border:1px dashed rgba(255,255,255,.35);
  color:rgba(255,255,255,.55); font-size:10px; letter-spacing:.06em;
  padding:0 8px;
}}
.regua-slot img {{ height:30px; width:auto; }}   /* mínimo digital H=5px (p. 12) */
.assinatura-orgao {{
  color:var(--branco); font-size:12px; line-height:1.25;
  text-align:right; padding-bottom:2px;
}}
.assinatura-orgao b {{ display:block; font-size:13px; }}
.filete {{
  height:4px; background:var(--vermelho);
  margin:0 calc(-1 * var(--gutter)) 22px;
}}

/* ---------- Títulos de seção (traço curto do manual) ---------- */
.secao {{ margin:26px 0 14px; }}
.secao h2 {{
  font-size:14px; font-weight:bold; text-transform:uppercase;
  letter-spacing:.06em; margin:0; color:var(--preto);
}}
.secao .traco {{
  display:block; width:26px; height:4px;
  background:var(--vermelho); margin-top:8px;
}}

/* ---------- Selo de referência ---------- */
.selo {{
  background:var(--amarelo); padding:10px 16px; text-align:right;
  display:inline-block;
}}
.selo p {{ margin:0; color:var(--preto); }}
.selo .rot {{ font-size:10px; text-transform:uppercase; letter-spacing:.08em; }}
.selo .val {{ font-size:15px; font-weight:bold; margin-top:2px; }}
.selo .ger {{ font-size:10.5px; margin-top:2px; }}

/* ---------- Cartão de indicador ---------- */
.cartao {{
  border:1px solid var(--cinza25); padding:14px 16px; height:100%;
  background:var(--branco);
}}
.cartao .rot {{
  font-size:10.5px; text-transform:uppercase; letter-spacing:.07em;
  color:var(--cinza50); margin:0; min-height:26px;
}}
.cartao .val {{
  font-size:28px; font-weight:bold; margin:4px 0 0; color:var(--preto);
  font-variant-numeric:tabular-nums; letter-spacing:-.01em;
}}
.cartao .apoio {{ font-size:11.5px; color:var(--cinza50); margin:4px 0 0; }}

/* ---------- Barras ---------- */
.barra {{ display:flex; align-items:center; gap:14px; margin-bottom:9px; }}
.barra .rot {{ font-size:12px; width:160px; flex-shrink:0; color:var(--preto); }}
.barra .trilho {{ flex:1; height:22px; background:#F2F2F2; }}
.barra .fill {{ height:100%; background:var(--serie); }}
.barra .val {{
  font-size:12px; width:70px; text-align:right; flex-shrink:0;
  font-variant-numeric:tabular-nums;
}}

/* ---------- Tabela ---------- */
table.gesp {{
  width:100%; border-collapse:collapse; font-size:13px;
  font-variant-numeric:tabular-nums;
}}
table.gesp th {{
  text-align:left; font-size:10.5px; text-transform:uppercase;
  letter-spacing:.06em; color:var(--cinza50); font-weight:bold;
  padding:0 0 8px; border-bottom:2px solid var(--preto);
}}
table.gesp td {{ padding:9px 0; border-bottom:1px solid var(--cinza25); }}
table.gesp tr:last-child td {{ border-bottom:none; }}
.abaixo {{ color:#8A6600; font-weight:bold; }}
.abaixo::before {{
  content:""; display:inline-block; width:8px; height:8px;
  background:var(--amarelo); margin-right:6px; vertical-align:1px;
}}
.tenue {{ color:var(--cinza50); }}

/* ---------- Leitura e estado vazio ---------- */
.leitura {{ border-left:4px solid var(--preto); padding:10px 0 10px 14px; }}
.leitura p {{ margin:0; font-size:13.5px; }}
.vazio {{
  border:1px dashed var(--cinza25); padding:36px 24px; text-align:center;
}}
.vazio .msg {{ font-size:15px; font-weight:bold; margin:0; }}
.vazio .acao {{
  font-size:12.5px; color:var(--cinza50); margin:10px auto 0;
  max-width:54ch; line-height:1.6;
}}
.nota {{ font-size:11.5px; color:var(--cinza50); line-height:1.6; margin:12px 0 0; }}

/* ---------- Barra lateral ---------- */
section[data-testid="stSidebar"] {{ background:var(--preto); width:270px !important; }}
section[data-testid="stSidebar"] * {{ color:var(--branco); }}
section[data-testid="stSidebar"] .marca-slot {{
  border:1px dashed rgba(255,255,255,.35); height:46px; display:flex;
  align-items:center; justify-content:center; color:rgba(255,255,255,.55);
  font-size:10px; letter-spacing:.06em; margin-bottom:14px;
}}
section[data-testid="stSidebar"] .lat-orgao {{
  font-size:11.5px; color:var(--cinza25); line-height:1.35;
}}
section[data-testid="stSidebar"] .lat-programa {{
  font-size:17px; font-weight:bold; margin:2px 0 0; color:var(--branco);
}}
section[data-testid="stSidebar"] .lat-rotulo {{
  font-size:10px; text-transform:uppercase; letter-spacing:.09em;
  color:var(--cinza50); margin:22px 0 4px;
}}
/* Rádio como navegação, com marcador vermelho no item ativo */
section[data-testid="stSidebar"] div[role="radiogroup"] label {{
  padding:7px 10px; border-left:4px solid transparent; margin-bottom:1px;
}}
section[data-testid="stSidebar"] div[role="radiogroup"] label:hover {{
  background:rgba(255,255,255,.07);
}}
section[data-testid="stSidebar"] div[role="radiogroup"] label:has(input:checked) {{
  border-left-color:var(--vermelho); background:rgba(255,255,255,.12);
}}
section[data-testid="stSidebar"] div[role="radiogroup"] input {{ display:none; }}
section[data-testid="stSidebar"] .lat-versao {{
  font-size:10.5px; color:var(--cinza50); margin-top:24px;
}}

@media (max-width:576px) {{      /* grid de 4 colunas, p. 26 */
  .block-container {{ padding-left:16px; padding-right:16px; }}
  .barra .rot {{ width:104px; }}
}}
</style>
"""


# =====================================================================
# FORMATAÇÃO
# =====================================================================

def num(v, casas=0) -> str:
    if v is None or pd.isna(v):
        return "—"
    s = f"{float(v):,.{casas}f}"
    return s.replace(",", "\x00").replace(".", ",").replace("\x00", ".")


def pct(v, casas=1) -> str:
    return "—" if v is None or pd.isna(v) else f"{num(v, casas)}%"


def taxa(a, b, casas=1) -> str:
    if not b or pd.isna(b) or pd.isna(a):
        return "—"
    return pct(100 * a / b, casas)


def marca_img(caminho: Path, alt: str, rotulo: str) -> str:
    """Logotipo embutido em base64, ou espaço reservado se o arquivo não existir."""
    if caminho.exists():
        mime = "image/svg+xml" if caminho.suffix == ".svg" else "image/png"
        b64 = base64.b64encode(caminho.read_bytes()).decode()
        return f'<div class="regua-slot"><img src="data:{mime};base64,{b64}" alt="{alt}"></div>'
    return f'<div class="regua-slot">{rotulo}</div>'


# =====================================================================
# COMPONENTES
# =====================================================================

def secao(titulo: str) -> None:
    st.markdown(
        f'<div class="secao"><h2>{titulo}</h2><span class="traco"></span></div>',
        unsafe_allow_html=True,
    )


def cartao(rotulo: str, valor: str, apoio: str = "") -> str:
    ap = f'<p class="apoio">{apoio}</p>' if apoio else ""
    return f'<div class="cartao"><p class="rot">{rotulo}</p><p class="val">{valor}</p>{ap}</div>'


def linha_cartoes(itens: list[tuple[str, str, str]], por_linha: int = 3) -> None:
    """Grid de 12 colunas: 3 cartões = 4 colunas cada (p. 26)."""
    for i in range(0, len(itens), por_linha):
        bloco = itens[i:i + por_linha]
        cols = st.columns(por_linha, gap="medium")
        for col, (rot, val, apoio) in zip(cols, bloco):
            col.markdown(cartao(rot, val, apoio), unsafe_allow_html=True)
        st.write("")


def barras(linhas: list[tuple[str, float]], total: float, opacidades=None) -> None:
    op = opacidades or [1.0] * len(linhas)
    html = []
    for (rot, val), o in zip(linhas, op):
        larg = 0 if not total else max(0.6, 100 * val / total)
        html.append(
            f'<div class="barra"><span class="rot">{rot}</span>'
            f'<span class="trilho"><span class="fill" style="width:{larg:.1f}%;opacity:{o}"></span></span>'
            f'<span class="val">{num(val)}</span></div>'
        )
    st.markdown("".join(html), unsafe_allow_html=True)


def tabela(df: pd.DataFrame, colunas: list[tuple[str, str, str]], larguras: list[str]) -> None:
    ths = "".join(
        f'<th style="width:{w};text-align:{a}">{c}</th>'
        for (_, c, a), w in zip(colunas, larguras)
    )
    trs = "".join(
        "<tr>" + "".join(f'<td style="text-align:{a}">{r[k]}</td>' for k, _, a in colunas) + "</tr>"
        for _, r in df.iterrows()
    )
    st.markdown(
        f'<table class="gesp"><thead><tr>{ths}</tr></thead><tbody>{trs}</tbody></table>',
        unsafe_allow_html=True,
    )


def nota(texto: str) -> None:
    st.markdown(f'<p class="nota">{texto}</p>', unsafe_allow_html=True)


def leitura(texto: str) -> None:
    st.markdown(f'<div class="leitura"><p>{texto}</p></div>', unsafe_allow_html=True)


def vazio(msg: str, acao: str = "") -> None:
    extra = f'<p class="acao">{acao}</p>' if acao else ""
    st.markdown(f'<div class="vazio"><p class="msg">{msg}</p>{extra}</div>', unsafe_allow_html=True)


# =====================================================================
# RELATÓRIOS
# =====================================================================

def rel_visao_geral(d: dict) -> None:
    f = d["funil"]
    f = f[f["data_ref"] == f["data_ref"].max()]
    t = d["tempos"]

    tot = {c: int(f[c].sum()) for c in f.columns if c.startswith("n_")}
    med = t.loc[t["etapa"] == "aceite_pactuacao", "p50"]
    med = med.median() if len(med) else None

    linha_cartoes([
        ("1 · Cobertura da busca ativa", taxa(tot["n_tentativa"], tot["n_elegivel"]),
         f'{num(tot["n_tentativa"])} de {num(tot["n_elegivel"])} elegíveis'),
        ("2 · Taxa de localização", taxa(tot["n_contato"], tot["n_tentativa"]),
         f'{num(tot["n_contato"])} contatos efetivos'),
        ("3 · Aceite do termo", taxa(tot["n_aceite"], tot["n_contato"]),
         f'{num(tot["n_aceite"])} famílias aceitaram'),
        ("4 · Conclusão do diagnóstico", taxa(tot["n_diag_fim"], tot["n_aceite"]),
         f'{num(tot["n_diag_fim"])} diagnósticos finalizados'),
        ("5 · Pactuação do PDF", taxa(tot["n_pdf_pactuado"], tot["n_diag_fim"]),
         f'{num(tot["n_pdf_pactuado"])} planos pactuados'),
        ("6 · Tempo até a pactuação", f"{num(med)} dias" if med else "—",
         "mediana do aceite ao plano"),
    ])

    secao("Onde as famílias saem do funil")
    barras(
        [("Elegíveis", tot["n_elegivel"]),
         ("Com tentativa", tot["n_tentativa"]),
         ("Contato efetivo", tot["n_contato"]),
         ("Termo aceito", tot["n_aceite"]),
         ("Diagnóstico final", tot["n_diag_fim"]),
         ("PDF pactuado", tot["n_pdf_pactuado"])],
        tot["n_elegivel"],
        opacidades=[1.0, 1.0, .82, .82, .62, .45],
    )
    nota(FONTE)


def rel_municipios(d: dict) -> None:
    f = d["funil"]
    f = f[f["data_ref"] == f["data_ref"].max()].copy().sort_values("n_elegivel", ascending=False)

    med_aceite = 100 * (f["n_aceite"] / f["n_contato"]).median()
    med_pact = 100 * (f["n_pdf_pactuado"] / f["n_diag_fim"]).median()

    def marcar(v, mediana):
        if pd.isna(v):
            return "—"
        return f'<span class="abaixo">{pct(v)}</span>' if v < mediana else pct(v)

    linhas = []
    for _, r in f.head(12).iterrows():
        pequeno = r["n_elegivel"] < N_MIN_COMPARATIVO
        a = 100 * r["n_aceite"] / r["n_contato"] if r["n_contato"] else float("nan")
        p = 100 * r["n_pdf_pactuado"] / r["n_diag_fim"] if r["n_diag_fim"] else float("nan")
        linhas.append({
            "municipio": f'<span class="tenue">{r["municipio"]}</span>' if pequeno else r["municipio"],
            "elegiveis": num(r["n_elegivel"]),
            "aceite": "—" if pequeno else marcar(a, med_aceite),
            "pactuacao": "—" if pequeno else marcar(p, med_pact),
        })

    linha_cartoes([
        ("Municípios com atividade", num((f["n_elegivel"] > 0).sum()), "de 645 no estado"),
        ("Concentração", taxa(f.nlargest(10, "n_elegivel")["n_elegivel"].sum(), f["n_elegivel"].sum()),
         "dos elegíveis nos 10 maiores"),
        ("Fora do comparativo", num((f["n_elegivel"] < N_MIN_COMPARATIVO).sum()),
         f"com menos de {N_MIN_COMPARATIVO} elegíveis"),
    ])

    secao("Maiores municípios por volume de elegíveis")
    tabela(
        pd.DataFrame(linhas),
        [("municipio", "Município", "left"), ("elegiveis", "Elegíveis", "right"),
         ("aceite", "Aceite", "right"), ("pactuacao", "Pactuação", "right")],
        ["40%", "20%", "20%", "20%"],
    )
    nota(
        f"Marcado em amarelo: abaixo da mediana estadual (aceite {pct(med_aceite)} · "
        f"pactuação {pct(med_pact)}). Ordenação por volume, não por desempenho. {FONTE}"
    )


def rel_recusas(d: dict) -> None:
    agg = (d["recusas"].groupby("categoria", as_index=False)["n"].sum()
           .sort_values("n", ascending=False))
    secao("Motivos declarados de recusa")
    barras(list(zip(agg["categoria"], agg["n"])), agg["n"].sum())
    nota(
        "Apenas categorias do menu suspenso do SIGMA. O campo de texto livre não entra "
        f"nesta contagem. {FONTE}"
    )


def rel_tempos(d: dict) -> None:
    t = d["tempos"]
    if t.empty:
        return vazio("Sem dados de tempo nesta competência.")
    nomes = {
        "tentativa_aceite": "Da primeira visita ao aceite",
        "aceite_diag_fim": "Do aceite ao diagnóstico final",
        "aceite_pactuacao": "Do aceite à pactuação",
        "diag_fim_pactuacao": "Do diagnóstico à pactuação",
    }
    agg = (t.groupby("etapa", as_index=False)
             .agg(p25=("p25", "median"), p50=("p50", "median"),
                  p75=("p75", "median"), n=("n", "sum"))
             .sort_values("p50"))
    df = pd.DataFrame({
        "etapa": agg["etapa"].map(nomes).fillna(agg["etapa"]),
        "p25": agg["p25"].map(lambda v: num(v)),
        "p50": agg["p50"].map(lambda v: f"<b>{num(v)}</b>"),
        "p75": agg["p75"].map(lambda v: num(v)),
        "n": agg["n"].map(num),
    })
    secao("Dias entre etapas")
    tabela(
        df,
        [("etapa", "Etapa", "left"), ("p25", "p25", "right"), ("p50", "Mediana", "right"),
         ("p75", "p75", "right"), ("n", "Famílias", "right")],
        ["40%", "14%", "16%", "14%", "16%"],
    )
    nota(f"Medianas dos municípios, em dias corridos. {FONTE}")


def rel_qualidade(d: dict) -> None:
    q = d["qualidade"]
    tot = int(q["n_familias"].sum())
    linha_cartoes([
        ("Cadastro CadÚnico vencido", taxa(q["n_cadunico_desatual"].sum(), tot),
         f'{num(q["n_cadunico_desatual"].sum())} famílias há mais de 24 meses'),
        ("Sem data de atualização", taxa(q["n_cadunico_sem_data"].sum(), tot),
         f'{num(q["n_cadunico_sem_data"].sum())} famílias'),
        ("Divergência de responsável", taxa(q["n_divergencia_rf"].sum(), tot),
         "RF do SIGMA difere do CadÚnico"),
    ])
    secao("Por que isto importa")
    leitura(
        "Cadastro vencido compromete a elegibilidade e o cálculo de benefício. "
        "Divergência de responsável familiar indica que a família foi abordada por "
        "pessoa diferente da registrada no CadÚnico, o que afeta a validade do termo de aceite."
    )
    nota(FONTE)


def rel_ebia(d: dict) -> None:
    vazio(
        "Relatório em construção.",
        "As classificações de insegurança alimentar apresentam variação entre meses "
        "compatível com artefato de cadastro. O relatório entra no painel quando a "
        "rotina de alertas estabilizar a série.",
    )


RELATORIOS = [
    {"titulo": "Visão geral",           "fn": rel_visao_geral, "status": "atual"},
    {"titulo": "Por município",         "fn": rel_municipios,  "status": "atual"},
    {"titulo": "Motivos de recusa",     "fn": rel_recusas,     "status": "atual"},
    {"titulo": "Tempos do processo",    "fn": rel_tempos,      "status": "atual"},
    {"titulo": "Qualidade do dado",     "fn": rel_qualidade,   "status": "atual"},
    {"titulo": "Insegurança alimentar", "fn": rel_ebia,        "status": "pendente"},
]

MARCADOR = {"atual": "●", "defasado": "◐", "pendente": "○"}


# =====================================================================
# DADOS
# =====================================================================

@st.cache_data(show_spinner=False)
def carregar(dir_tabelas: str) -> dict[str, pd.DataFrame]:
    p = Path(dir_tabelas)
    return {n: pd.read_csv(p / f"{n}.csv") for n in ["funil", "tempos", "recusas", "qualidade"]}


# =====================================================================
# APLICAÇÃO
# =====================================================================

def main() -> None:
    st.set_page_config(
        page_title=f"{PROGRAMA} — painel de acompanhamento",
        layout="wide",
        initial_sidebar_state="expanded",
    )
    st.markdown(css(), unsafe_allow_html=True)

    # ---------- Barra lateral ----------
    with st.sidebar:
        st.markdown(
            '<div class="marca-slot">ESPAÇO PARA O BRASÃO</div>'
            f'<p class="lat-orgao">{ORGAO}</p>'
            f'<p class="lat-programa">{PROGRAMA}</p>'
            '<p class="lat-rotulo">Relatórios</p>',
            unsafe_allow_html=True,
        )
        escolha = st.radio(
            "Relatórios",
            options=[r["titulo"] for r in RELATORIOS],
            format_func=lambda t: f"{MARCADOR[next(r['status'] for r in RELATORIOS if r['titulo'] == t)]}  {t}",
            label_visibility="collapsed",
        )
        st.markdown(
            '<p class="lat-rotulo">Situação do dado</p>'
            '<p class="lat-orgao">● competência atual<br>'
            '◐ competência anterior<br>○ ainda não disponível</p>'
            f'<p class="lat-versao">{VERSAO}</p>',
            unsafe_allow_html=True,
        )

    rel = next(r for r in RELATORIOS if r["titulo"] == escolha)

    # ---------- Assinatura institucional ----------
    # Régua: parceiros à esquerda, secretaria, e o logotipo do Governo sempre
    # à direita (manual p. 19 e 21).
    parceiros = "".join(marca_img(p, "logotipo parceiro", "PARCEIRO") for p in LOGO_PARCEIROS)
    governo = marca_img(LOGO_GOVERNO, "São Paulo — Governo do Estado", "LOGOTIPO SP")
    st.markdown(
        f'<div class="faixa">'
        f'  <div><p class="faixa-titulo">{rel["titulo"]}</p>'
        f'     <p class="faixa-sub">{PROGRAMA} · acompanhamento da busca ativa</p></div>'
        f'  <div class="regua">{parceiros}'
        f'     <div class="assinatura-orgao">Secretaria de<b>Desenvolvimento Social</b></div>'
        f'     {governo}</div>'
        f'</div><div class="filete"></div>',
        unsafe_allow_html=True,
    )

    # ---------- Selo de referência ----------
    esq, dir_ = st.columns([3, 1], gap="medium")
    with dir_:
        st.markdown(
            f'<div class="selo"><p class="rot">Dados de referência</p>'
            f'<p class="val">{COMPETENCIA}</p>'
            f'<p class="ger">painel gerado em {datetime.now().strftime("%d/%m/%Y às %H:%M")}</p></div>',
            unsafe_allow_html=True,
        )

    # ---------- Relatório ----------
    try:
        dados = carregar(str(DIR_TABELAS))
    except Exception as e:
        vazio("Tabelas da camada agregada não encontradas.",
              f"Esperado em {DIR_TABELAS.resolve()} — {type(e).__name__}: {e}")
        return

    try:
        rel["fn"](dados)
    except Exception as e:
        vazio("Não foi possível montar este relatório.", f"{type(e).__name__}: {e}")

    nota(NOTA_SUPRESSAO + " Documento de uso interno. Não contém dados pessoais.")


if __name__ == "__main__":
    main()
